import com.sun.source.doctree.ThrowsTree;
import menus.*;
public class Main
{

    public static void main(String[] args)
    {
        MainMenu mainMenu = new MainMenu();
        mainMenu.menu();

    }
}


