package staff;

public class Role
{
    public static final String INTERN = "staff.Intern";
    public static final String REGULAR = "staff.RegularEmployee";
    public static final String MANAGER = "staff.Manager";
    public static final String DIRECTOR = "staff.Director";
}
